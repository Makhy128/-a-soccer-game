import React, { useState } from "react";
import SoccerGame from "./SoccerGame";

export default function App() {
  const [started, setStarted] = useState(false);

  return (
    <div>
      <h1>3D Soccer Game (Multiplayer)</h1>
      {!started ? (
        <div style={{ textAlign: "center" }}>
          <p>
            Welcome! Click Play to join a multiplayer soccer match.<br />
            Use arrow keys or WASD to move, Space to kick.
          </p>
          <button onClick={() => setStarted(true)}>Play</button>
        </div>
      ) : (
        <SoccerGame />
      )}
    </div>
  );
}