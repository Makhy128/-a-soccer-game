import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { io } from "socket.io-client";
import Chat from "./components/Chat";
import Scoreboard from "./components/Scoreboard";

const SERVER_URL = "http://localhost:4000"; // Change this to your deployed server URL

export default function SoccerGame() {
  const mountRef = useRef(null);
  const [socket, setSocket] = useState(null);
  const [playerId, setPlayerId] = useState(null);
  const [players, setPlayers] = useState({});
  const [teams, setTeams] = useState({});
  const [ball, setBall] = useState({ x: 0, z: 0 });
  const [score, setScore] = useState({ red: 0, blue: 0 });
  const [messages, setMessages] = useState([]);

  // Three.js refs
  const threeObjects = useRef({});

  useEffect(() => {
    // Connect to server
    const sock = io(SERVER_URL);
    setSocket(sock);

    // HANDLERS

    // Initial setup from server
    sock.on("init", ({ id, players, ball, teams, score }) => {
      setPlayerId(id);
      setPlayers(players);
      setTeams(teams);
      setBall(ball);
      setScore(score);
    });

    // Player joined
    sock.on("playerJoined", ({ id, player, team }) => {
      setPlayers(prev => ({ ...prev, [id]: player }));
      setTeams(prev => ({ ...prev, [id]: team }));
    });

    // Player left
    sock.on("playerLeft", ({ id }) => {
      setPlayers(prev => {
        const copy = { ...prev };
        delete copy[id];
        return copy;
      });
      setTeams(prev => {
        const copy = { ...prev };
        delete copy[id];
        return copy;
      });
    });

    // Player moved
    sock.on("playerMoved", ({ id, x, z }) => {
      setPlayers(prev => ({ ...prev, [id]: { ...prev[id], x, z } }));
    });

    // Ball updated
    sock.on("ballUpdate", ({ x, z }) => {
      setBall({ x, z });
    });

    // Score update
    sock.on("scoreUpdate", score => setScore(score));

    // Chat message
    sock.on("chat", msg => setMessages(prev => [...prev, msg]));

    // Clean up
    return () => {
      sock.disconnect();
    };
  }, []);

  // THREE.js setup and animation
  useEffect(() => {
    if (!mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      mountRef.current.clientWidth / mountRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.set(0, 15, 25);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
    mountRef.current.appendChild(renderer.domElement);

    // Field
    const field = new THREE.Mesh(
      new THREE.PlaneGeometry(20, 30),
      new THREE.MeshLambertMaterial({ color: 0x228b22 })
    );
    field.rotation.x = -Math.PI / 2;
    scene.add(field);

    // Goals (visual only)
    const goalMat = new THREE.MeshLambertMaterial({ color: 0xffffff });
    const goal1 = new THREE.Mesh(new THREE.BoxGeometry(8, 2, 0.5), goalMat);
    goal1.position.set(0, 1, -15);
    scene.add(goal1);
    const goal2 = new THREE.Mesh(new THREE.BoxGeometry(8, 2, 0.5), goalMat);
    goal2.position.set(0, 1, 15);
    scene.add(goal2);

    // Lighting
    scene.add(new THREE.AmbientLight(0xffffff, 0.7));
    const dirLight = new THREE.DirectionalLight(0xffffff, 0.7);
    dirLight.position.set(10, 20, 10);
    scene.add(dirLight);

    // Store refs to players/ball meshes
    threeObjects.current = { playerMeshes: {}, ballMesh: null };

    // Ball mesh
    const ballMesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.5, 32, 32),
      new THREE.MeshStandardMaterial({ color: 0xffffff })
    );
    scene.add(ballMesh);
    threeObjects.current.ballMesh = ballMesh;

    // Animation loop
    let animationId;
    function animate() {
      // Update player meshes
      Object.entries(players).forEach(([id, p]) => {
        if (!threeObjects.current.playerMeshes[id]) {
          // New mesh
          const color = teams[id] === "red" ? 0xff4444 : 0x3366ff;
          const mesh = new THREE.Mesh(
            new THREE.BoxGeometry(1, 2, 1),
            new THREE.MeshStandardMaterial({ color })
          );
          mesh.position.set(p.x, 1, p.z);
          scene.add(mesh);
          threeObjects.current.playerMeshes[id] = mesh;
        } else {
          // Update position
          threeObjects.current.playerMeshes[id].position.set(p.x, 1, p.z);
        }
      });

      // Remove meshes for disconnected players
      Object.keys(threeObjects.current.playerMeshes).forEach(id => {
        if (!players[id]) {
          scene.remove(threeObjects.current.playerMeshes[id]);
          delete threeObjects.current.playerMeshes[id];
        }
      });

      // Ball
      if (threeObjects.current.ballMesh) {
        threeObjects.current.ballMesh.position.set(ball.x, 0.5, ball.z);
      }

      renderer.render(scene, camera);
      animationId = requestAnimationFrame(animate);
    }
    animate();

    // Handle controls
    let keys = {};
    const playerSpeed = 0.25;

    function handleKeyDown(e) {
      keys[e.key.toLowerCase()] = true;
      if (e.key === " ") {
        // Kick if near ball
        const my = players[playerId];
        if (my && Math.abs(my.x - ball.x) < 2 && Math.abs(my.z - ball.z) < 2) {
          // Determine direction
          const dz = ball.z - my.z;
          const dir = dz > 0 ? 1 : -1;
          socket.emit("kick", { dir });
        }
      }
    }
    function handleKeyUp(e) {
      keys[e.key.toLowerCase()] = false;
    }

    function movePlayer() {
      if (!players[playerId]) return;
      let { x, z } = players[playerId];
      if (keys["arrowup"] || keys["w"]) z -= playerSpeed;
      if (keys["arrowdown"] || keys["s"]) z += playerSpeed;
      if (keys["arrowleft"] || keys["a"]) x -= playerSpeed;
      if (keys["arrowright"] || keys["d"]) x += playerSpeed;
      // Clamp
      x = Math.max(-9.5, Math.min(9.5, x));
      z = Math.max(-14.5, Math.min(14.5, z));
      // Only emit if position changed
      if (x !== players[playerId].x || z !== players[playerId].z) {
        socket.emit("move", { x, z });
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("keyup", handleKeyUp);

    const moveInterval = setInterval(movePlayer, 16);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationId);
      clearInterval(moveInterval);
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("keyup", handleKeyUp);
      renderer.dispose();
      mountRef.current.removeChild(renderer.domElement);
    };
    // eslint-disable-next-line
  }, [players, ball, teams, socket, playerId]);

  // Chat send
  const handleSendMessage = msg => {
    if (socket && msg.trim()) socket.emit("chat", msg);
  };

  return (
    <div>
      <Scoreboard teams={teams} score={score} />
      <div ref={mountRef} style={{ width: "100%", height: "500px", border: "2px solid #228B22" }} />
      <Chat messages={messages} onSend={handleSendMessage} />
    </div>
  );
}