const express = require("express");
const http = require("http");
const socketIo = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: "*" } });

let players = {};
let ball = { x: 0, z: 0, vz: 0 };

io.on("connection", (socket) => {
  // Assign new player
  players[socket.id] = { x: 0, z: -10, color: Math.random() * 0xffffff };

  // Send initial state
  socket.emit("init", { id: socket.id, players, ball });

  // Broadcast new player
  socket.broadcast.emit("playerJoined", { id: socket.id, player: players[socket.id] });

  // Handle player move
  socket.on("move", (data) => {
    if (players[socket.id]) {
      players[socket.id].x = data.x;
      players[socket.id].z = data.z;
      io.emit("playerMoved", { id: socket.id, x: data.x, z: data.z });
    }
  });

  // Handle kick
  socket.on("kick", (data) => {
    ball.vz = data.vz;
    io.emit("ballKicked", { vz: data.vz });
  });

  // Ball state update
  setInterval(() => {
    if (Math.abs(ball.vz) > 0.01) {
      ball.z += ball.vz;
      ball.vz *= 0.98;
      io.emit("ballUpdate", { x: ball.x, z: ball.z, vz: ball.vz });
    }
  }, 50);

  socket.on("disconnect", () => {
    delete players[socket.id];
    io.emit("playerLeft", { id: socket.id });
  });
});

server.listen(4000, () => console.log("Server running on port 4000"));